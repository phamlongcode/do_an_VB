﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient

Public Class Form1
    Private ReadOnly connStr As String =
        ConfigurationManager.ConnectionStrings("QLSV").ConnectionString

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cboGioiTinh.Items.Clear()
        cboGioiTinh.Items.AddRange(New String() {"Nam", "Nữ"})
        If cboGioiTinh.Items.Count > 0 Then cboGioiTinh.SelectedIndex = 0
        LoadSinhVien()
    End Sub

    Private Sub LoadSinhVien()
        Using cn As New SqlConnection(connStr),
              da As New SqlDataAdapter("SELECT SV_ID, HoTen, NgaySinh, GioiTinh, LopID FROM SINHVIEN ORDER BY SV_ID", cn)
            Dim tb As New DataTable()
            da.Fill(tb)
            dgvSinhVien.DataSource = tb
        End Using
        If dgvSinhVien.Columns.Contains("SV_ID") Then dgvSinhVien.Columns("SV_ID").HeaderText = "Mã SV"
        If dgvSinhVien.Columns.Contains("HoTen") Then dgvSinhVien.Columns("HoTen").HeaderText = "Họ Tên"
        If dgvSinhVien.Columns.Contains("NgaySinh") Then dgvSinhVien.Columns("NgaySinh").HeaderText = "Ngày sinh"
        If dgvSinhVien.Columns.Contains("GioiTinh") Then dgvSinhVien.Columns("GioiTinh").HeaderText = "Giới tính"
        If dgvSinhVien.Columns.Contains("LopID") Then dgvSinhVien.Columns("LopID").HeaderText = "Lớp"
    End Sub

    Private Sub ClearInputs()
        txtMaSV.Clear()
        txtHoTen.Clear()
        dtpNgaySinh.Value = Date.Today
        cboGioiTinh.SelectedIndex = 0
        txtLop.Clear()
        txtLop.Clear()
        txtMaSV.Focus()
    End Sub

    Private Sub EnsureKhoaExists(khoaId As String, tenKhoa As String)
        Using cn As New SqlConnection(connStr)
            cn.Open()
            Using chk As New SqlCommand("SELECT COUNT(*) FROM KHOA WHERE KhoaID=@id", cn)
                chk.Parameters.AddWithValue("@id", khoaId.Trim())
                Dim c As Integer = CInt(chk.ExecuteScalar())
                If c = 0 Then
                    Using ins As New SqlCommand("INSERT INTO KHOA(KhoaID, TenKhoa) VALUES(@id,@ten)", cn)
                        ins.Parameters.AddWithValue("@id", khoaId.Trim())
                        ins.Parameters.AddWithValue("@ten", tenKhoa.Trim())
                        ins.ExecuteNonQuery()
                    End Using
                End If
            End Using
        End Using
    End Sub

    Private Sub EnsureLopExists(lopId As String, tenLop As String)
        If String.IsNullOrWhiteSpace(lopId) Then Throw New Exception("Mã lớp không được để trống.")
        Dim defKhoa As String = "KHAC"        ' đổi thành "CNTT" nếu bạn muốn
        Dim tenDefKhoa As String = "Khác"     ' đổi tên khoa mặc định nếu cần

        EnsureKhoaExists(defKhoa, tenDefKhoa)

        Using cn As New SqlConnection(connStr)
            cn.Open()
            Using checkCmd As New SqlCommand("SELECT COUNT(*) FROM LOP WHERE LopID=@id", cn)
                checkCmd.Parameters.AddWithValue("@id", lopId.Trim())
                Dim count As Integer = CInt(checkCmd.ExecuteScalar())
                If count = 0 Then
                    Using insCmd As New SqlCommand(
                    "INSERT INTO LOP(LopID, TenLop, KhoaID) VALUES(@id,@ten,@khoa)", cn)
                        insCmd.Parameters.AddWithValue("@id", lopId.Trim())
                        insCmd.Parameters.AddWithValue("@ten", If(String.IsNullOrWhiteSpace(tenLop), lopId.Trim(), tenLop.Trim()))
                        insCmd.Parameters.AddWithValue("@khoa", defKhoa)
                        insCmd.ExecuteNonQuery()
                    End Using
                End If
            End Using
        End Using
    End Sub


    Private Sub dgvSinhVien_SelectionChanged(sender As Object, e As EventArgs) Handles dgvSinhVien.SelectionChanged
        If dgvSinhVien.CurrentRow Is Nothing Then Return
        txtMaSV.Text = dgvSinhVien.CurrentRow.Cells("SV_ID").Value?.ToString()
        txtHoTen.Text = dgvSinhVien.CurrentRow.Cells("HoTen").Value?.ToString()
        Dim ns = dgvSinhVien.CurrentRow.Cells("NgaySinh").Value
        If ns IsNot DBNull.Value AndAlso ns IsNot Nothing Then dtpNgaySinh.Value = CDate(ns)
        cboGioiTinh.Text = dgvSinhVien.CurrentRow.Cells("GioiTinh").Value?.ToString()
        txtLop.Text = dgvSinhVien.CurrentRow.Cells("LopID").Value?.ToString()
        If String.IsNullOrWhiteSpace(txtLop.Text) AndAlso Not String.IsNullOrWhiteSpace(txtLop.Text) Then
            txtLop.Text = txtLop.Text
        End If
    End Sub

    Private Sub btnThem_Click(sender As Object, e As EventArgs) Handles btnThem.Click
        If String.IsNullOrWhiteSpace(txtMaSV.Text) OrElse String.IsNullOrWhiteSpace(txtHoTen.Text) Then
            MessageBox.Show("Nhập Mã SV và Họ Tên.")
            Return
        End If
        If String.IsNullOrWhiteSpace(txtLop.Text) Then
            MessageBox.Show("Nhập Mã lớp.")
            Return
        End If

        EnsureLopExists(txtLop.Text.Trim(), txtLop.Text.Trim())

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("
                INSERT INTO SINHVIEN(SV_ID,HoTen,NgaySinh,GioiTinh,LopID)
                VALUES(@id,@ten,@ns,@gt,@lop)", cn)
            cmd.Parameters.AddWithValue("@id", txtMaSV.Text.Trim())
            cmd.Parameters.AddWithValue("@ten", txtHoTen.Text.Trim())
            cmd.Parameters.AddWithValue("@ns", dtpNgaySinh.Value.Date)
            cmd.Parameters.AddWithValue("@gt", cboGioiTinh.Text)
            cmd.Parameters.AddWithValue("@lop", txtLop.Text.Trim())
            cn.Open()
            cmd.ExecuteNonQuery()
        End Using

        LoadSinhVien()
        ClearInputs()
    End Sub

    Private Sub btnSua_Click(sender As Object, e As EventArgs) Handles btnSua.Click
        If String.IsNullOrWhiteSpace(txtMaSV.Text) Then
            MessageBox.Show("Chọn sinh viên cần sửa.")
            Return
        End If
        If String.IsNullOrWhiteSpace(txtLop.Text) Then
            MessageBox.Show("Nhập Mã lớp.")
            Return
        End If

        EnsureLopExists(txtLop.Text.Trim(), txtLop.Text.Trim())

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("
                UPDATE SINHVIEN
                   SET HoTen=@ten, NgaySinh=@ns, GioiTinh=@gt, LopID=@lop
                 WHERE SV_ID=@id", cn)
            cmd.Parameters.AddWithValue("@ten", txtHoTen.Text.Trim())
            cmd.Parameters.AddWithValue("@ns", dtpNgaySinh.Value.Date)
            cmd.Parameters.AddWithValue("@gt", cboGioiTinh.Text)
            cmd.Parameters.AddWithValue("@lop", txtLop.Text.Trim())
            cmd.Parameters.AddWithValue("@id", txtMaSV.Text.Trim())
            cn.Open()
            Dim n = cmd.ExecuteNonQuery()
            If n = 0 Then MessageBox.Show("Không tìm thấy Mã SV cần cập nhật.")
        End Using

        LoadSinhVien()
    End Sub

    Private Sub btnXoa_Click(sender As Object, e As EventArgs) Handles btnXoa.Click
        If String.IsNullOrWhiteSpace(txtMaSV.Text) Then Return
        If MessageBox.Show("Xóa sinh viên này?", "Xác nhận", MessageBoxButtons.YesNo) = DialogResult.No Then Return

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("DELETE FROM SINHVIEN WHERE SV_ID=@id", cn)
            cmd.Parameters.AddWithValue("@id", txtMaSV.Text.Trim())
            cn.Open()
            cmd.ExecuteNonQuery()
        End Using

        LoadSinhVien()
        ClearInputs()
    End Sub

    Private Sub btnThoat_Click(sender As Object, e As EventArgs) Handles btnThoat.Click
        Close()
    End Sub
    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Application.Exit()
    End Sub

    Private Sub btnMon_Click(sender As Object, e As EventArgs) Handles btnMon.Click
        Dim f As New frmMon()
        f.StartPosition = FormStartPosition.CenterScreen
        Me.Hide()
        f.ShowDialog()
        Me.Close()
    End Sub
End Class
