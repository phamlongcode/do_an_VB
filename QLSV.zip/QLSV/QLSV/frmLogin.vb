﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class frmLogin
    Private ReadOnly connStr As String =
        ConfigurationManager.ConnectionStrings("QLSV").ConnectionString


    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If String.IsNullOrWhiteSpace(txtUser.Text) OrElse String.IsNullOrWhiteSpace(txtPass.Text) Then
            MessageBox.Show("Vui lòng nhập đầy đủ tài khoản và mật khẩu!", "Thông báo")
            Return
        End If

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("SELECT COUNT(*) FROM NGUOIDUNG WHERE UserName=@u AND Password=@p", cn)
            cmd.Parameters.AddWithValue("@u", txtUser.Text.Trim())
            cmd.Parameters.AddWithValue("@p", txtPass.Text.Trim())
            cn.Open()
            Dim count As Integer = CInt(cmd.ExecuteScalar())
            If count > 0 Then
                MessageBox.Show("Đăng nhập thành công!", "Thông báo")
                Me.Hide()
                Form1.Show()
            Else
                MessageBox.Show("Sai tài khoản hoặc mật khẩu!", "Lỗi")
            End If
        End Using
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub btnThoat_Click(sender As Object, e As EventArgs) Handles btnThoat.Click
        Application.Exit()
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
