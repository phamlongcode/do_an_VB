﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblMaSV = New System.Windows.Forms.Label()
        Me.txtMaSV = New System.Windows.Forms.TextBox()
        Me.lblHoTen = New System.Windows.Forms.Label()
        Me.txtHoTen = New System.Windows.Forms.TextBox()
        Me.lblNgaySinh = New System.Windows.Forms.Label()
        Me.dtpNgaySinh = New System.Windows.Forms.DateTimePicker()
        Me.lblGioiTinh = New System.Windows.Forms.Label()
        Me.cboGioiTinh = New System.Windows.Forms.ComboBox()
        Me.lblLop = New System.Windows.Forms.Label()
        Me.dgvSinhVien = New System.Windows.Forms.DataGridView()
        Me.btnThem = New System.Windows.Forms.Button()
        Me.btnSua = New System.Windows.Forms.Button()
        Me.btnXoa = New System.Windows.Forms.Button()
        Me.btnThoat = New System.Windows.Forms.Button()
        Me.txtLop = New System.Windows.Forms.TextBox()
        Me.btnMon = New System.Windows.Forms.Button()
        CType(Me.dgvSinhVien, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMaSV
        '
        Me.lblMaSV.AutoSize = True
        Me.lblMaSV.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMaSV.Location = New System.Drawing.Point(38, 71)
        Me.lblMaSV.Name = "lblMaSV"
        Me.lblMaSV.Size = New System.Drawing.Size(72, 24)
        Me.lblMaSV.TabIndex = 0
        Me.lblMaSV.Text = "Mã SV"
        '
        'txtMaSV
        '
        Me.txtMaSV.Location = New System.Drawing.Point(158, 76)
        Me.txtMaSV.Name = "txtMaSV"
        Me.txtMaSV.Size = New System.Drawing.Size(244, 20)
        Me.txtMaSV.TabIndex = 1
        '
        'lblHoTen
        '
        Me.lblHoTen.AutoSize = True
        Me.lblHoTen.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHoTen.Location = New System.Drawing.Point(38, 109)
        Me.lblHoTen.Name = "lblHoTen"
        Me.lblHoTen.Size = New System.Drawing.Size(76, 24)
        Me.lblHoTen.TabIndex = 2
        Me.lblHoTen.Text = "Họ Tên"
        '
        'txtHoTen
        '
        Me.txtHoTen.Location = New System.Drawing.Point(158, 113)
        Me.txtHoTen.Name = "txtHoTen"
        Me.txtHoTen.Size = New System.Drawing.Size(244, 20)
        Me.txtHoTen.TabIndex = 3
        '
        'lblNgaySinh
        '
        Me.lblNgaySinh.AutoSize = True
        Me.lblNgaySinh.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNgaySinh.Location = New System.Drawing.Point(38, 159)
        Me.lblNgaySinh.Name = "lblNgaySinh"
        Me.lblNgaySinh.Size = New System.Drawing.Size(101, 24)
        Me.lblNgaySinh.TabIndex = 4
        Me.lblNgaySinh.Text = "Ngày Sinh"
        '
        'dtpNgaySinh
        '
        Me.dtpNgaySinh.Location = New System.Drawing.Point(158, 163)
        Me.dtpNgaySinh.Name = "dtpNgaySinh"
        Me.dtpNgaySinh.Size = New System.Drawing.Size(200, 20)
        Me.dtpNgaySinh.TabIndex = 5
        '
        'lblGioiTinh
        '
        Me.lblGioiTinh.AutoSize = True
        Me.lblGioiTinh.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGioiTinh.Location = New System.Drawing.Point(38, 207)
        Me.lblGioiTinh.Name = "lblGioiTinh"
        Me.lblGioiTinh.Size = New System.Drawing.Size(93, 24)
        Me.lblGioiTinh.TabIndex = 6
        Me.lblGioiTinh.Text = "Giới Tính"
        '
        'cboGioiTinh
        '
        Me.cboGioiTinh.FormattingEnabled = True
        Me.cboGioiTinh.Items.AddRange(New Object() {"Nam", "Nữ"})
        Me.cboGioiTinh.Location = New System.Drawing.Point(158, 210)
        Me.cboGioiTinh.Name = "cboGioiTinh"
        Me.cboGioiTinh.Size = New System.Drawing.Size(121, 21)
        Me.cboGioiTinh.TabIndex = 7
        '
        'lblLop
        '
        Me.lblLop.AutoSize = True
        Me.lblLop.Font = New System.Drawing.Font("Times New Roman", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLop.Location = New System.Drawing.Point(38, 264)
        Me.lblLop.Name = "lblLop"
        Me.lblLop.Size = New System.Drawing.Size(47, 24)
        Me.lblLop.TabIndex = 8
        Me.lblLop.Text = "Lớp"
        '
        'dgvSinhVien
        '
        Me.dgvSinhVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSinhVien.Location = New System.Drawing.Point(513, 67)
        Me.dgvSinhVien.Name = "dgvSinhVien"
        Me.dgvSinhVien.Size = New System.Drawing.Size(529, 284)
        Me.dgvSinhVien.TabIndex = 10
        '
        'btnThem
        '
        Me.btnThem.Location = New System.Drawing.Point(42, 328)
        Me.btnThem.Name = "btnThem"
        Me.btnThem.Size = New System.Drawing.Size(75, 23)
        Me.btnThem.TabIndex = 11
        Me.btnThem.Text = "Thêm"
        Me.btnThem.UseVisualStyleBackColor = True
        '
        'btnSua
        '
        Me.btnSua.Location = New System.Drawing.Point(135, 328)
        Me.btnSua.Name = "btnSua"
        Me.btnSua.Size = New System.Drawing.Size(75, 23)
        Me.btnSua.TabIndex = 12
        Me.btnSua.Text = "Sửa"
        Me.btnSua.UseVisualStyleBackColor = True
        '
        'btnXoa
        '
        Me.btnXoa.Location = New System.Drawing.Point(231, 328)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(75, 23)
        Me.btnXoa.TabIndex = 13
        Me.btnXoa.Text = "Xóa"
        Me.btnXoa.UseVisualStyleBackColor = True
        '
        'btnThoat
        '
        Me.btnThoat.Location = New System.Drawing.Point(327, 328)
        Me.btnThoat.Name = "btnThoat"
        Me.btnThoat.Size = New System.Drawing.Size(75, 23)
        Me.btnThoat.TabIndex = 14
        Me.btnThoat.Text = "Thoát"
        Me.btnThoat.UseVisualStyleBackColor = True
        '
        'txtLop
        '
        Me.txtLop.Location = New System.Drawing.Point(158, 268)
        Me.txtLop.Name = "txtLop"
        Me.txtLop.Size = New System.Drawing.Size(244, 20)
        Me.txtLop.TabIndex = 15
        '
        'btnMon
        '
        Me.btnMon.Location = New System.Drawing.Point(424, 328)
        Me.btnMon.Name = "btnMon"
        Me.btnMon.Size = New System.Drawing.Size(75, 23)
        Me.btnMon.TabIndex = 16
        Me.btnMon.Text = "Quản lý môn"
        Me.btnMon.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.ClientSize = New System.Drawing.Size(1054, 428)
        Me.Controls.Add(Me.btnMon)
        Me.Controls.Add(Me.txtLop)
        Me.Controls.Add(Me.btnThoat)
        Me.Controls.Add(Me.btnXoa)
        Me.Controls.Add(Me.btnSua)
        Me.Controls.Add(Me.btnThem)
        Me.Controls.Add(Me.dgvSinhVien)
        Me.Controls.Add(Me.lblLop)
        Me.Controls.Add(Me.cboGioiTinh)
        Me.Controls.Add(Me.lblGioiTinh)
        Me.Controls.Add(Me.dtpNgaySinh)
        Me.Controls.Add(Me.lblNgaySinh)
        Me.Controls.Add(Me.txtHoTen)
        Me.Controls.Add(Me.lblHoTen)
        Me.Controls.Add(Me.txtMaSV)
        Me.Controls.Add(Me.lblMaSV)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.dgvSinhVien, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMaSV As Label
    Friend WithEvents txtMaSV As TextBox
    Friend WithEvents lblHoTen As Label
    Friend WithEvents txtHoTen As TextBox
    Friend WithEvents lblNgaySinh As Label
    Friend WithEvents dtpNgaySinh As DateTimePicker
    Friend WithEvents lblGioiTinh As Label
    Friend WithEvents cboGioiTinh As ComboBox
    Friend WithEvents lblLop As Label
    Friend WithEvents dgvSinhVien As DataGridView
    Friend WithEvents btnThem As Button
    Friend WithEvents btnSua As Button
    Friend WithEvents btnXoa As Button
    Friend WithEvents btnThoat As Button
    Friend WithEvents txtLop As TextBox
    Friend WithEvents btnMon As Button
End Class
