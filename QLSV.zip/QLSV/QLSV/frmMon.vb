﻿Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient

Public Class frmMon
    Private ReadOnly connStr As String =
        ConfigurationManager.ConnectionStrings("QLSV").ConnectionString

    Private Sub frmMon_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        LoadMon()
    End Sub

    Private Sub LoadMon()
        Using cn As New SqlConnection(connStr),
              da As New SqlDataAdapter("SELECT MonID, TenMon, SoTinChi FROM MON ORDER BY MonID", cn)
            Dim tb As New DataTable()
            da.Fill(tb)
            dgvMon.DataSource = tb
        End Using

        If dgvMon.Columns.Contains("MonID") Then dgvMon.Columns("MonID").HeaderText = "Mã môn"
        If dgvMon.Columns.Contains("TenMon") Then dgvMon.Columns("TenMon").HeaderText = "Tên môn"
        If dgvMon.Columns.Contains("SoTinChi") Then dgvMon.Columns("SoTinChi").HeaderText = "Số tín chỉ"
    End Sub

    Private Sub ClearInputs()
        txtMaMon.Clear()
        txtTenMon.Clear()
        txtSoTC.Clear()
        txtMaMon.Focus()
    End Sub

    Private Sub dgvMon_SelectionChanged(sender As Object, e As EventArgs) Handles dgvMon.SelectionChanged
        If dgvMon.CurrentRow Is Nothing Then Return
        txtMaMon.Text = dgvMon.CurrentRow.Cells("MonID").Value?.ToString()
        txtTenMon.Text = dgvMon.CurrentRow.Cells("TenMon").Value?.ToString()
        txtSoTC.Text = dgvMon.CurrentRow.Cells("SoTinChi").Value?.ToString()
    End Sub

    Private Sub btnThemMon_Click(sender As Object, e As EventArgs) Handles btnThemMon.Click
        If String.IsNullOrWhiteSpace(txtMaMon.Text) OrElse String.IsNullOrWhiteSpace(txtTenMon.Text) Then
            MessageBox.Show("Nhập Mã môn và Tên môn.")
            Return
        End If

        Dim stc As Integer
        If Not Integer.TryParse(txtSoTC.Text.Trim(), stc) OrElse stc <= 0 Then
            MessageBox.Show("Số tín chỉ phải là số > 0.")
            Return
        End If

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("INSERT INTO MON(MonID, TenMon, SoTinChi) VALUES(@id,@ten,@tc)", cn)
            cmd.Parameters.AddWithValue("@id", txtMaMon.Text.Trim())
            cmd.Parameters.AddWithValue("@ten", txtTenMon.Text.Trim())
            cmd.Parameters.AddWithValue("@tc", stc)
            cn.Open()
            cmd.ExecuteNonQuery()
        End Using

        LoadMon()
        ClearInputs()
    End Sub

    Private Sub btnSuaMon_Click(sender As Object, e As EventArgs) Handles btnSuaMon.Click
        If String.IsNullOrWhiteSpace(txtMaMon.Text) Then
            MessageBox.Show("Chọn môn cần sửa.")
            Return
        End If

        Dim stc As Integer
        If Not Integer.TryParse(txtSoTC.Text.Trim(), stc) OrElse stc <= 0 Then
            MessageBox.Show("Số tín chỉ phải là số > 0.")
            Return
        End If

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("UPDATE MON SET TenMon=@ten, SoTinChi=@tc WHERE MonID=@id", cn)
            cmd.Parameters.AddWithValue("@ten", txtTenMon.Text.Trim())
            cmd.Parameters.AddWithValue("@tc", stc)
            cmd.Parameters.AddWithValue("@id", txtMaMon.Text.Trim())
            cn.Open()
            Dim n = cmd.ExecuteNonQuery()
            If n = 0 Then MessageBox.Show("Không tìm thấy Mã môn cần cập nhật.")
        End Using

        LoadMon()
    End Sub

    Private Sub btnXoaMon_Click(sender As Object, e As EventArgs) Handles btnXoaMon.Click
        If String.IsNullOrWhiteSpace(txtMaMon.Text) Then Return
        If MessageBox.Show("Xóa môn này?", "Xác nhận", MessageBoxButtons.YesNo) = DialogResult.No Then Return

        Using cn As New SqlConnection(connStr),
              cmd As New SqlCommand("DELETE FROM MON WHERE MonID=@id", cn)
            cmd.Parameters.AddWithValue("@id", txtMaMon.Text.Trim())
            cn.Open()
            cmd.ExecuteNonQuery()
        End Using

        LoadMon()
        ClearInputs()
    End Sub

    Private Sub btnThoatMon_Click(sender As Object, e As EventArgs) Handles btnThoatMon.Click
        Close()
    End Sub
End Class
