﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMon
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbMaMon = New System.Windows.Forms.Label()
        Me.lbTenMon = New System.Windows.Forms.Label()
        Me.lbSoTC = New System.Windows.Forms.Label()
        Me.txtMaMon = New System.Windows.Forms.TextBox()
        Me.txtTenMon = New System.Windows.Forms.TextBox()
        Me.txtSoTC = New System.Windows.Forms.TextBox()
        Me.btnThemMon = New System.Windows.Forms.Button()
        Me.btnSuaMon = New System.Windows.Forms.Button()
        Me.btnXoaMon = New System.Windows.Forms.Button()
        Me.btnThoatMon = New System.Windows.Forms.Button()
        Me.dgvMon = New System.Windows.Forms.DataGridView()
        CType(Me.dgvMon, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft YaHei", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(227, 44)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(298, 36)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "QUẢN LÝ MÔN HỌC"
        '
        'lbMaMon
        '
        Me.lbMaMon.AutoSize = True
        Me.lbMaMon.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbMaMon.Location = New System.Drawing.Point(47, 120)
        Me.lbMaMon.Name = "lbMaMon"
        Me.lbMaMon.Size = New System.Drawing.Size(77, 22)
        Me.lbMaMon.TabIndex = 1
        Me.lbMaMon.Text = "Mã môn"
        '
        'lbTenMon
        '
        Me.lbTenMon.AutoSize = True
        Me.lbTenMon.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbTenMon.Location = New System.Drawing.Point(47, 177)
        Me.lbTenMon.Name = "lbTenMon"
        Me.lbTenMon.Size = New System.Drawing.Size(81, 22)
        Me.lbTenMon.TabIndex = 2
        Me.lbTenMon.Text = "Tên môn"
        '
        'lbSoTC
        '
        Me.lbSoTC.AutoSize = True
        Me.lbSoTC.Font = New System.Drawing.Font("Microsoft YaHei", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbSoTC.Location = New System.Drawing.Point(47, 227)
        Me.lbSoTC.Name = "lbSoTC"
        Me.lbSoTC.Size = New System.Drawing.Size(84, 22)
        Me.lbSoTC.TabIndex = 3
        Me.lbSoTC.Text = "Số tín chỉ"
        '
        'txtMaMon
        '
        Me.txtMaMon.Location = New System.Drawing.Point(158, 120)
        Me.txtMaMon.Name = "txtMaMon"
        Me.txtMaMon.Size = New System.Drawing.Size(184, 20)
        Me.txtMaMon.TabIndex = 4
        '
        'txtTenMon
        '
        Me.txtTenMon.Location = New System.Drawing.Point(158, 177)
        Me.txtTenMon.Name = "txtTenMon"
        Me.txtTenMon.Size = New System.Drawing.Size(184, 20)
        Me.txtTenMon.TabIndex = 5
        '
        'txtSoTC
        '
        Me.txtSoTC.Location = New System.Drawing.Point(158, 230)
        Me.txtSoTC.Name = "txtSoTC"
        Me.txtSoTC.Size = New System.Drawing.Size(184, 20)
        Me.txtSoTC.TabIndex = 7
        '
        'btnThemMon
        '
        Me.btnThemMon.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnThemMon.Location = New System.Drawing.Point(67, 363)
        Me.btnThemMon.Name = "btnThemMon"
        Me.btnThemMon.Size = New System.Drawing.Size(109, 49)
        Me.btnThemMon.TabIndex = 8
        Me.btnThemMon.Text = "Thêm "
        Me.btnThemMon.UseVisualStyleBackColor = True
        '
        'btnSuaMon
        '
        Me.btnSuaMon.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnSuaMon.Location = New System.Drawing.Point(233, 363)
        Me.btnSuaMon.Name = "btnSuaMon"
        Me.btnSuaMon.Size = New System.Drawing.Size(109, 49)
        Me.btnSuaMon.TabIndex = 9
        Me.btnSuaMon.Text = "Sửa"
        Me.btnSuaMon.UseVisualStyleBackColor = True
        '
        'btnXoaMon
        '
        Me.btnXoaMon.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnXoaMon.Location = New System.Drawing.Point(401, 363)
        Me.btnXoaMon.Name = "btnXoaMon"
        Me.btnXoaMon.Size = New System.Drawing.Size(109, 49)
        Me.btnXoaMon.TabIndex = 10
        Me.btnXoaMon.Text = "Xóa"
        Me.btnXoaMon.UseVisualStyleBackColor = True
        '
        'btnThoatMon
        '
        Me.btnThoatMon.Font = New System.Drawing.Font("Microsoft YaHei UI", 12.0!, System.Drawing.FontStyle.Bold)
        Me.btnThoatMon.Location = New System.Drawing.Point(550, 363)
        Me.btnThoatMon.Name = "btnThoatMon"
        Me.btnThoatMon.Size = New System.Drawing.Size(109, 49)
        Me.btnThoatMon.TabIndex = 11
        Me.btnThoatMon.Text = "Thoát"
        Me.btnThoatMon.UseVisualStyleBackColor = True
        '
        'dgvMon
        '
        Me.dgvMon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMon.Location = New System.Drawing.Point(401, 120)
        Me.dgvMon.Name = "dgvMon"
        Me.dgvMon.Size = New System.Drawing.Size(387, 210)
        Me.dgvMon.TabIndex = 12
        '
        'frmMon
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.dgvMon)
        Me.Controls.Add(Me.btnThoatMon)
        Me.Controls.Add(Me.btnXoaMon)
        Me.Controls.Add(Me.btnSuaMon)
        Me.Controls.Add(Me.btnThemMon)
        Me.Controls.Add(Me.txtSoTC)
        Me.Controls.Add(Me.txtTenMon)
        Me.Controls.Add(Me.txtMaMon)
        Me.Controls.Add(Me.lbSoTC)
        Me.Controls.Add(Me.lbTenMon)
        Me.Controls.Add(Me.lbMaMon)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmMon"
        Me.Text = "frmMon"
        CType(Me.dgvMon, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents lbMaMon As Label
    Friend WithEvents lbTenMon As Label
    Friend WithEvents lbSoTC As Label
    Friend WithEvents txtMaMon As TextBox
    Friend WithEvents txtTenMon As TextBox
    Friend WithEvents txtSoTC As TextBox
    Friend WithEvents btnThemMon As Button
    Friend WithEvents btnSuaMon As Button
    Friend WithEvents btnXoaMon As Button
    Friend WithEvents btnThoatMon As Button
    Friend WithEvents dgvMon As DataGridView
End Class
